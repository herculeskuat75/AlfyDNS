# Aturan ProGuard AlfyDNS
-keep class com.alfydns.app.** { *; }
-keep class go.** { *; }
-dontwarn org.slf4j.**
-dontwarn javax.naming.**
-dontwarn org.ietf.jgss.**
-dontwarn sun.security.x509.**
-dontwarn com.sun.jna.**
-dontwarn net.i2p.crypto.eddsa.**
-dontwarn org.bouncycastle.**
