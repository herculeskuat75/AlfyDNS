package com.alfydns.app

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LogState {
    private const val MAX = 100
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    fun addLog(message: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "[$t] $message"
        while (true) {
            val cur = _logs.value
            if (_logs.compareAndSet(cur, (cur + line).takeLast(MAX))) break
        }
    }

    fun clearLog() {
        _logs.value = emptyList()
    }
}
