package com.alfydns.app

import android.os.ParcelFileDescriptor
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import net.schmizz.sshj.connection.channel.direct.DirectConnection
import java.io.DataInputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.random.Random

/**
 * Stack TCP/IP userspace minimalis.
 * Baca paket IPv4 dari TUN -> TCP: terminasi lokal, payload diteruskan ke SshLink.open(host, port);
 * data balik dari SSH dibungkus paket TCP dan ditulis ke TUN. UDP port 53 dikirim sebagai DNS-over-TCP lewat SSH.
 */
class TunStack(private val pfd: ParcelFileDescriptor) {

    private data class Key(val src: Int, val sp: Int, val dst: Int, val dp: Int)

    private val input = FileInputStream(pfd.fileDescriptor)
    private val output = FileOutputStream(pfd.fileDescriptor)
    private val writeLock = Any()
    private val conns = ConcurrentHashMap<Key, Conn>()
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "tun-io").also { it.isDaemon = true } }
    private val scope = CoroutineScope(SupervisorJob() + pool.asCoroutineDispatcher())

    @Volatile private var running = false
    private var reader: Thread? = null
    private var ipId = 0

    // UDPGW (badvpn-udpgw): satu koneksi TCP ke forwarder lokal, semua alur UDP di-multiplex dengan conid.
    private class UFlow(val conId: Int, val src: Int, val sp: Int, val dst: Int, val dp: Int) {
        @Volatile var last = System.currentTimeMillis()
    }
    private val udpFlows = ConcurrentHashMap<Key, UFlow>()
    private val udpById = ConcurrentHashMap<Int, UFlow>()
    private val udpLock = Any()
    private var nextConId = 0
    private val udpOut = Channel<ByteArray>(512)
    private val gwLock = Any()
    @Volatile private var gwSock: Socket? = null

    fun start() {
        if (running) return
        running = true
        reader = Thread({ readLoop() }, "tun-reader").also { it.isDaemon = true; it.start() }
        scope.launch { udpgwWriter() }
        scope.launch {
            while (running) {
                delay(60_000)
                val now = System.currentTimeMillis()
                for (c in conns.values) if (now - c.lastActive > IDLE_MS) c.close(rst = true)
                for (f in udpFlows.values) if (now - f.last > UDP_IDLE_MS) {
                    udpFlows.remove(Key(f.src, f.sp, f.dst, f.dp)); udpById.remove(f.conId)
                }
            }
        }
    }

    fun stop() {
        running = false
        for (c in conns.values) c.close(rst = false)
        conns.clear()
        udpOut.close()
        closeGw()
        udpFlows.clear(); udpById.clear()
        scope.cancel()
        try { pool.shutdownNow() } catch (_: Throwable) {}
        try { input.close() } catch (_: Throwable) {}
        try { output.close() } catch (_: Throwable) {}
        try { pfd.close() } catch (_: Throwable) {}
        reader?.interrupt()
    }

    // ---------------------------------------------------------------- baca TUN

    private fun readLoop() {
        val buf = ByteArray(32767)
        while (running) {
            val n = try { input.read(buf) } catch (e: IOException) { break }
            if (n < 0) break
            if (n == 0) continue
            try { handle(buf, n) } catch (e: Throwable) { Log.w(TAG, "paket gagal", e) }
        }
        Log.i(TAG, "reader berhenti")
    }

    private fun handle(b: ByteArray, len: Int) {
        if (len < 20 || ((b[0].toInt() ushr 4) and 0xF) != 4) return
        val ihl = (b[0].toInt() and 0xF) * 4
        val total = u16(b, 2)
        if (ihl < 20 || total < ihl || len < ihl) return
        if ((u16(b, 6) and 0x3FFF) != 0) return // fragmen diabaikan
        val end = minOf(total, len)
        val proto = b[9].toInt() and 0xFF
        val src = i32(b, 12)
        val dst = i32(b, 16)
        when (proto) {
            6 -> handleTcp(b, ihl, end, src, dst)
            17 -> handleUdp(b, ihl, end, src, dst)
        }
    }

    private fun handleTcp(b: ByteArray, ip: Int, end: Int, src: Int, dst: Int) {
        if (end - ip < 20) return
        val sp = u16(b, ip)
        val dp = u16(b, ip + 2)
        val seq = u32(b, ip + 4)
        val ack = u32(b, ip + 8)
        val off = ((b[ip + 12].toInt() ushr 4) and 0xF) * 4
        val flags = b[ip + 13].toInt() and 0x3F
        val wnd = u16(b, ip + 14)
        if (off < 20 || ip + off > end) return
        val ds = ip + off
        val dl = end - ds
        val key = Key(src, sp, dst, dp)
        val syn = flags and SYN != 0
        val hasAck = flags and ACK != 0
        val rst = flags and RST != 0
        val c = conns[key]
        if (c == null) {
            if (syn && !hasAck) {
                val nc = Conn(key, seq)
                if (conns.putIfAbsent(key, nc) == null) nc.open()
            } else if (!rst) {
                val fin = if (flags and FIN != 0) 1 else 0
                if (hasAck) sendTcp(dst, src, dp, sp, ack, 0, RST, 0, null, 0, 0, false)
                else sendTcp(dst, src, dp, sp, 0, (seq + dl + fin) and MASK, RST or ACK, 0, null, 0, 0, false)
            }
            return
        }
        c.lastActive = System.currentTimeMillis()
        if (rst) { c.close(rst = false); return }
        if (syn) { c.resendSynAck(seq); return }
        if (!c.established) return
        c.onSegment(seq, ack, hasAck, flags and FIN != 0, wnd, b, ds, dl)
    }

    private fun handleUdp(b: ByteArray, ip: Int, end: Int, src: Int, dst: Int) {
        if (end - ip < 8) return
        val sp = u16(b, ip)
        val dp = u16(b, ip + 2)
        val ulen = u16(b, ip + 4)
        val pe = minOf(end, ip + ulen)
        if (pe <= ip + 8) return
        val q = b.copyOfRange(ip + 8, pe)
        if (dp != 53) {
            // UDP selain DNS: lewat UDPGW bila aktif, kalau tidak dibuang.
            if (SshLink.udpgwPort > 0) udpgwEnqueue(src, sp, dst, dp, q)
            return
        }
        scope.launch { dnsOverSsh(src, sp, dst, q) }
    }

    private suspend fun dnsOverSsh(src: Int, sp: Int, dst: Int, q: ByteArray) {
        var ch: DirectConnection? = null
        val killer = scope.launch { delay(8_000); try { ch?.close() } catch (_: Throwable) {} }
        try {
            val c = SshLink.open(ipStr(dst), 53)
            ch = c
            val out = c.outputStream
            val msg = ByteArray(q.size + 2)
            msg[0] = (q.size ushr 8).toByte(); msg[1] = q.size.toByte()
            System.arraycopy(q, 0, msg, 2, q.size)
            out.write(msg); out.flush()
            val din = DataInputStream(c.inputStream)
            val rl = din.readUnsignedShort()
            val resp = ByteArray(rl)
            din.readFully(resp)
            sendUdp(dst, src, 53, sp, resp)
        } catch (e: Throwable) {
            Log.w(TAG, "DNS gagal: ${e.message}")
        } finally {
            killer.cancel()
            try { ch?.close() } catch (_: Throwable) {}
        }
    }

    // ---------------------------------------------------------------- UDPGW

    /** Bungkus datagram jadi frame badvpn-udpgw dan antrekan (tidak memblokir thread pembaca TUN). */
    private fun udpgwEnqueue(src: Int, sp: Int, dst: Int, dp: Int, data: ByteArray) {
        if (data.size > 65535 - 9) return
        val key = Key(src, sp, dst, dp)
        val f = udpFlows[key] ?: synchronized(udpLock) {
            udpFlows[key] ?: run {
                var id = nextConId
                do { id = (id + 1) and 0xFFFF } while (id == 0)
                nextConId = id
                udpById.remove(id)?.let { old -> udpFlows.remove(Key(old.src, old.sp, old.dst, old.dp)) }
                UFlow(id, src, sp, dst, dp).also { udpFlows[key] = it; udpById[id] = it }
            }
        }
        f.last = System.currentTimeMillis()
        // Frame: len(2,LE) | flags(1) | conid(2,LE) | ip(4,BE) | port(2,BE) | payload
        val pl = 9 + data.size
        val buf = ByteArray(2 + pl)
        buf[0] = pl.toByte(); buf[1] = (pl ushr 8).toByte()
        buf[2] = 0
        buf[3] = f.conId.toByte(); buf[4] = (f.conId ushr 8).toByte()
        put32(buf, 5, dst.toLong() and MASK)
        put16(buf, 9, dp)
        System.arraycopy(data, 0, buf, 11, data.size)
        udpOut.trySend(buf) // penuh -> datagram dibuang (semantik UDP)
    }

    private suspend fun udpgwWriter() {
        for (frame in udpOut) {
            val port = SshLink.udpgwPort
            if (port <= 0) continue
            try {
                val s = gwSocket(port) ?: continue
                s.getOutputStream().write(frame)
            } catch (e: Throwable) {
                Log.w(TAG, "UDPGW kirim gagal: ${e.message}")
                closeGw()
            }
        }
    }

    private fun gwSocket(port: Int): Socket? {
        gwSock?.let { if (!it.isClosed) return it }
        synchronized(gwLock) {
            gwSock?.let { if (!it.isClosed) return it }
            val s = Socket()
            try {
                s.connect(InetSocketAddress("127.0.0.1", port), 3000)
                s.tcpNoDelay = true
            } catch (e: Throwable) {
                try { s.close() } catch (_: Throwable) {}
                throw e
            }
            gwSock = s
            scope.launch { gwReader(s) }
            return s
        }
    }

    private fun closeGw() {
        synchronized(gwLock) {
            try { gwSock?.close() } catch (_: Throwable) {}
            gwSock = null
        }
    }

    /** Baca frame balasan server, kembalikan sebagai paket UDP ke aplikasi asal lewat TUN. */
    private fun gwReader(s: Socket) {
        try {
            val din = DataInputStream(s.getInputStream().buffered())
            while (running) {
                val lo = din.read()
                if (lo < 0) break
                val hi = din.read()
                if (hi < 0) break
                val len = lo or (hi shl 8)
                val f = ByteArray(len)
                din.readFully(f)
                if (len < 9) continue
                val flags = f[0].toInt() and 0xFF
                if ((flags and 0x01) != 0 || (flags and 0x08) != 0) continue // keepalive / IPv6: abaikan
                val conId = (f[1].toInt() and 0xFF) or ((f[2].toInt() and 0xFF) shl 8)
                val fl = udpById[conId] ?: continue
                fl.last = System.currentTimeMillis()
                sendUdp(fl.dst, fl.src, fl.dp, fl.sp, f.copyOfRange(9, len))
            }
        } catch (e: Throwable) {
            if (running) Log.w(TAG, "UDPGW baca berhenti: ${e.message}")
        } finally {
            if (gwSock === s) closeGw()
        }
    }

    // ---------------------------------------------------------------- koneksi TCP

    private inner class Conn(val key: Key, val clientIsn: Long) {
        @Volatile var lastActive = System.currentTimeMillis()
        @Volatile var established = false
        @Volatile private var closed = false
        private val iss = Random.nextLong(1, 0x7FFFFFFF)
        private var rcvNxt = (clientIsn + 1) and MASK
        private var sndNxt = iss
        private var sndUna = iss
        private var peerWnd = 65535
        private var finSent = false
        private var finRecv = false
        private var ssh: DirectConnection? = null
        private val toSsh = Channel<ByteArray>(256)

        fun open() {
            scope.launch {
                try {
                    val c = SshLink.open(ipStr(key.dst), key.dp)
                    ssh = c
                    if (closed) { try { c.close() } catch (_: Throwable) {}; return@launch }
                    synchronized(this@Conn) {
                        sendSeg(SYN or ACK, iss, rcvNxt, null, 0, 0, true)
                        sndNxt = (iss + 1) and MASK
                        sndUna = sndNxt
                        established = true
                    }
                } catch (e: Throwable) {
                    Log.w(TAG, "open ${ipStr(key.dst)}:${key.dp} gagal: ${e.message}")
                    sendTcp(key.dst, key.src, key.dp, key.sp, 0, (clientIsn + 1) and MASK, RST or ACK, 0, null, 0, 0, false)
                    conns.remove(key)
                    return@launch
                }
                scope.launch { writeLoop(c = ssh!!) }
                readLoop(ssh!!)
            }
        }

        fun resendSynAck(seq: Long) {
            synchronized(this) {
                if (established && seq == clientIsn && sndNxt == ((iss + 1) and MASK))
                    sendSeg(SYN or ACK, iss, rcvNxt, null, 0, 0, true)
            }
        }

        private fun sendSeg(flags: Int, seq: Long, ack: Long, p: ByteArray?, po: Int, pl: Int, mss: Boolean) {
            sendTcp(key.dst, key.src, key.dp, key.sp, seq, ack, flags, WINDOW, p, po, pl, mss)
        }

        fun onSegment(seq: Long, ack: Long, hasAck: Boolean, fin: Boolean, wnd: Int, b: ByteArray, ds: Int, dl: Int) {
            var accept = true
            synchronized(this) {
                if (hasAck) {
                    if (diff(ack, sndUna) > 0 && diff(sndNxt, ack) >= 0) sndUna = ack
                    peerWnd = wnd
                    (this as java.lang.Object).notifyAll()
                }
                var needAck = false
                if (dl > 0) {
                    if (seq == rcvNxt) {
                        if (toSsh.trySend(b.copyOfRange(ds, ds + dl)).isSuccess) {
                            rcvNxt = (rcvNxt + dl) and MASK
                            needAck = true
                        } else accept = false // antrean penuh: jangan ACK, klien kirim ulang
                    } else needAck = true // di luar urutan / duplikat
                }
                if (fin && accept && !finRecv && ((seq + dl) and MASK) == rcvNxt) {
                    finRecv = true
                    rcvNxt = (rcvNxt + 1) and MASK
                    toSsh.close()
                    needAck = true
                }
                if (fin && finRecv) needAck = true
                if (needAck) sendSeg(ACK, sndNxt, rcvNxt, null, 0, 0, false)
                if (finSent && finRecv && sndUna == sndNxt) close(rst = false)
            }
        }

        private suspend fun writeLoop(c: DirectConnection) {
            try {
                val out = c.outputStream
                for (chunk in toSsh) { out.write(chunk); out.flush() }
                out.close() // EOF ke sisi remote
            } catch (e: Throwable) {
                if (!closed) close(rst = true)
            }
        }

        private fun readLoop(c: DirectConnection) {
            val buf = ByteArray(MSS)
            try {
                val ins = c.inputStream
                while (!closed) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    if (!awaitWindow()) { close(rst = true); return }
                    synchronized(this) {
                        if (closed) return
                        sendSeg(ACK or PSH, sndNxt, rcvNxt, buf, 0, n, false)
                        sndNxt = (sndNxt + n) and MASK
                    }
                    lastActive = System.currentTimeMillis()
                }
                synchronized(this) {
                    if (closed) return
                    sendSeg(FIN or ACK, sndNxt, rcvNxt, null, 0, 0, false)
                    sndNxt = (sndNxt + 1) and MASK
                    finSent = true
                    if (finRecv && sndUna == sndNxt) close(rst = false)
                }
            } catch (e: Throwable) {
                if (!closed) close(rst = true)
            }
        }

        private fun awaitWindow(): Boolean {
            val deadline = System.currentTimeMillis() + 60_000
            return synchronized(this) {
                var ok = true
                while (!closed && inFlight() >= minOf(peerWnd, MAX_FLIGHT)) {
                    if (System.currentTimeMillis() > deadline) { ok = false; break }
                    (this as java.lang.Object).wait(1000)
                }
                ok && !closed
            }
        }

        private fun inFlight(): Long = (sndNxt - sndUna) and MASK

        fun close(rst: Boolean) {
            synchronized(this) {
                if (closed) return
                closed = true
                if (rst && established) sendSeg(RST or ACK, sndNxt, rcvNxt, null, 0, 0, false)
                (this as java.lang.Object).notifyAll()
            }
            conns.remove(key)
            toSsh.close()
            try { ssh?.close() } catch (_: Throwable) {}
        }
    }

    // ---------------------------------------------------------------- bangun paket

    private fun sendTcp(
        src: Int, dst: Int, sp: Int, dp: Int, seq: Long, ack: Long, flags: Int, win: Int,
        p: ByteArray?, po: Int, pl: Int, mss: Boolean
    ) {
        val opt = if (mss) 4 else 0
        val tl = 20 + opt + pl
        val pkt = ByteArray(20 + tl)
        ipHeader(pkt, 20 + tl, 6, src, dst)
        val t = 20
        put16(pkt, t, sp); put16(pkt, t + 2, dp)
        put32(pkt, t + 4, seq); put32(pkt, t + 8, ack)
        pkt[t + 12] = (((20 + opt) / 4) shl 4).toByte()
        pkt[t + 13] = flags.toByte()
        put16(pkt, t + 14, win)
        if (mss) { pkt[t + 20] = 2; pkt[t + 21] = 4; put16(pkt, t + 22, MSS) }
        if (p != null && pl > 0) System.arraycopy(p, po, pkt, t + 20 + opt, pl)
        put16(pkt, t + 16, csum(pkt, t, tl, pseudo(src, dst, 6, tl)))
        writeTun(pkt)
    }

    private fun sendUdp(src: Int, dst: Int, sp: Int, dp: Int, payload: ByteArray) {
        val ul = 8 + payload.size
        val pkt = ByteArray(20 + ul)
        ipHeader(pkt, 20 + ul, 17, src, dst)
        put16(pkt, 20, sp); put16(pkt, 22, dp); put16(pkt, 24, ul)
        System.arraycopy(payload, 0, pkt, 28, payload.size)
        var c = csum(pkt, 20, ul, pseudo(src, dst, 17, ul))
        if (c == 0) c = 0xFFFF
        put16(pkt, 26, c)
        writeTun(pkt)
    }

    private fun ipHeader(pkt: ByteArray, total: Int, proto: Int, src: Int, dst: Int) {
        pkt[0] = 0x45
        put16(pkt, 2, total)
        put16(pkt, 4, synchronized(this) { ipId = (ipId + 1) and 0xFFFF; ipId })
        put16(pkt, 6, 0x4000)
        pkt[8] = 64
        pkt[9] = proto.toByte()
        put32(pkt, 12, src.toLong() and MASK)
        put32(pkt, 16, dst.toLong() and MASK)
        put16(pkt, 10, csum(pkt, 0, 20, 0))
    }

    private fun writeTun(pkt: ByteArray) {
        if (!running) return
        try {
            synchronized(writeLock) { output.write(pkt) }
        } catch (e: IOException) {
            Log.w(TAG, "tulis TUN gagal: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- util

    private fun pseudo(src: Int, dst: Int, proto: Int, len: Int): Long =
        ((src ushr 16) + (src and 0xFFFF) + (dst ushr 16) + (dst and 0xFFFF) + proto + len).toLong()

    private fun csum(b: ByteArray, off: Int, len: Int, init: Long): Int {
        var s = init
        var i = off
        val e = off + len
        while (i + 1 < e) {
            s += (((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < e) s += ((b[i].toInt() and 0xFF) shl 8).toLong()
        while ((s ushr 16) != 0L) s = (s and 0xFFFF) + (s ushr 16)
        return (s.inv() and 0xFFFF).toInt()
    }

    private fun diff(a: Long, b: Long): Int = (a - b).toInt()
    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun i32(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or
            ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)
    private fun u32(b: ByteArray, o: Int): Long = i32(b, o).toLong() and MASK
    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v ushr 8).toByte(); b[o + 1] = v.toByte() }
    private fun put32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v ushr 24).toByte(); b[o + 1] = (v ushr 16).toByte(); b[o + 2] = (v ushr 8).toByte(); b[o + 3] = v.toByte()
    }
    private fun ipStr(a: Int) = "${(a ushr 24) and 0xFF}.${(a ushr 16) and 0xFF}.${(a ushr 8) and 0xFF}.${a and 0xFF}"

    private companion object {
        const val TAG = "TunStack"
        const val FIN = 0x01
        const val SYN = 0x02
        const val RST = 0x04
        const val PSH = 0x08
        const val ACK = 0x10
        const val MSS = 1240
        const val WINDOW = 65535
        const val MAX_FLIGHT = 32 * 1024
        const val IDLE_MS = 10 * 60_000L
        const val UDP_IDLE_MS = 60_000L
        const val MASK = 0xFFFFFFFFL
    }
}
