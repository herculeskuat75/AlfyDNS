package com.alfydns.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalViewConfiguration
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import java.util.UUID

private val Rainbow = listOf(
    Color(0xFF00E5FF), Color(0xFF2979FF), Color(0xFFD500F9), Color(0xFFFF1744),
    Color(0xFFFF9100), Color(0xFFFFEA00), Color(0xFF00E676)
)

/**
 * Panel config: ketuk = pakai, tekan 0,5 detik lalu geser = ubah urutan.
 * draft = isi input saat ini (dipakai sebagai nilai awal tombol Tambah).
 */
@Composable
fun ConfigPanel(
    configs: List<Config>,
    selectedId: String?,
    connected: Boolean,
    draft: Config,
    onSelect: (Config) -> Unit,
    onSave: (Config) -> Unit,
    onDelete: (Config) -> Unit,
    onMove: (from: Int, to: Int) -> Unit,
    onReorderEnd: () -> Unit
) {
    var editing by remember { mutableStateOf<Config?>(null) }
    var draggingId by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val listState = rememberLazyListState()

    // Tahan 500 ms sebelum drag aktif.
    val base = LocalViewConfiguration.current
    val vc = remember(base) {
        object : ViewConfiguration by base {
            override val longPressTimeoutMillis: Long = 500L
        }
    }

    CompositionLocalProvider(LocalViewConfiguration provides vc) {
        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Config", fontSize = 28.sp)
                Button(onClick = { editing = draft.copy(id = UUID.randomUUID().toString(), name = "") }) {
                    Text("+ Tambah")
                }
            }
            Box(
                Modifier.fillMaxWidth().height(3.dp)
                    .background(Brush.horizontalGradient(Rainbow))
            )

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(configs, key = { it.id }) { cfg ->
                    val isSel = cfg.id == selectedId
                    val isDrag = cfg.id == draggingId
                    var menu by remember { mutableStateOf(false) }
                    val shape = RoundedCornerShape(16.dp)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .zIndex(if (isDrag) 1f else 0f)
                            .graphicsLayer {
                                translationY = if (isDrag) dragOffset else 0f
                                if (isDrag) { scaleX = 1.03f; scaleY = 1.03f }
                            }
                            .clip(shape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .then(
                                if (isSel) Modifier.border(2.dp, Brush.sweepGradient(Rainbow + Rainbow.first()), shape)
                                else Modifier
                            )
                            .pointerInput(cfg.id) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { draggingId = cfg.id; dragOffset = 0f },
                                    onDrag = { change, amount ->
                                        change.consume()
                                        dragOffset += amount.y
                                        val infos = listState.layoutInfo.visibleItemsInfo
                                        val me = infos.firstOrNull { it.key == cfg.id }
                                        if (me != null) {
                                            val center = me.offset + me.size / 2f + dragOffset
                                            val target = infos.firstOrNull {
                                                it.key != cfg.id && center >= it.offset && center < it.offset + it.size
                                            }
                                            if (target != null) {
                                                onMove(me.index, target.index)
                                                dragOffset += (me.offset - target.offset)
                                            }
                                        }
                                    },
                                    onDragEnd = { draggingId = null; dragOffset = 0f; onReorderEnd() },
                                    onDragCancel = { draggingId = null; dragOffset = 0f; onReorderEnd() }
                                )
                            }
                            .clickable { onSelect(cfg) }
                            .padding(horizontal = 14.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "●",
                                    color = if (isSel && connected) Color(0xFF00C853) else Color(0xFFFF1744),
                                    fontSize = 16.sp
                                )
                                Text(
                                    "  " + cfg.name.ifBlank { "Config" },
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                            Text(
                                "DNSTT · " + cfg.ns.ifBlank { "-" },
                                fontSize = 12.sp,
                                maxLines = 1,
                                modifier = Modifier.alpha(0.7f)
                            )
                        }
                        Text("👍", fontSize = 22.sp, modifier = Modifier.alpha(if (isSel) 1f else 0.3f))
                        Box {
                            TextButton(onClick = { menu = true }) { Text("⋮", fontSize = 20.sp) }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; editing = cfg })
                                DropdownMenuItem(text = { Text("Hapus") }, onClick = { menu = false; onDelete(cfg) })
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { e ->
        var name by remember(e.id) { mutableStateOf(e.name) }
        var server by remember(e.id) { mutableStateOf(e.server) }
        var resolver by remember(e.id) { mutableStateOf(e.resolver) }
        var ns by remember(e.id) { mutableStateOf(e.ns) }
        var key by remember(e.id) { mutableStateOf(e.key) }
        AlertDialog(
            onDismissRequest = { editing = null },
            confirmButton = {
                TextButton(onClick = {
                    onSave(Config(e.id, name.ifBlank { ns.ifBlank { "Config" } }, server, resolver, ns, key))
                    editing = null
                }) { Text("Simpan") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Batal") } },
            title = { Text("Config") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Nama") }, singleLine = true)
                    OutlinedTextField(server, { server = it }, label = { Text("Server (host:port@user:password)") }, singleLine = true)
                    OutlinedTextField(resolver, { resolver = it }, label = { Text("DNS Resolver") }, singleLine = true)
                    OutlinedTextField(ns, { ns = it }, label = { Text("NS Server") }, singleLine = true)
                    OutlinedTextField(key, { key = it }, label = { Text("Public Key") }, singleLine = true)
                }
            }
        )
    }
}
