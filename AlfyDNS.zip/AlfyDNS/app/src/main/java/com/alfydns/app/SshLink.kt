package com.alfydns.app

import net.schmizz.sshj.DefaultConfig
import net.schmizz.sshj.SSHClient
import net.schmizz.keepalive.KeepAliveProvider
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import net.schmizz.sshj.connection.channel.direct.DirectConnection
import net.schmizz.sshj.connection.channel.direct.Parameters
import kotlin.concurrent.thread
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketAddress
import javax.net.SocketFactory

object SshLink {

    private const val CONNECT_TIMEOUT_MS = 20_000

    // SSH selalu ke port lokal tunnel dnstt, bukan ke host/port dari UI.
    private const val LOCAL_HOST = "127.0.0.1"
    private val LOCAL_PORT = DnsttWrapper.LISTEN_ADDR.substringAfterLast(':').toInt()

    private class Target(val host: String, val port: Int, val user: String, val pass: String)

    /** Socket langsung ke tunnel lokal; connect() kedua dari SSHJ diabaikan karena sudah tersambung. */
    private class DirectSocket : Socket() {
        override fun connect(endpoint: SocketAddress, timeout: Int) {
            if (!isConnected) super.connect(endpoint, timeout)
        }
    }

    private var target: Target? = null
    private var socket: Socket? = null
    private var client: SSHClient? = null
    private var udpgwSocket: ServerSocket? = null

    /** Port lokal forwarder UDPGW yang sedang aktif (0 = nonaktif). Dibaca TunStack. */
    @Volatile var udpgwPort: Int = 0
        private set

    val isConnected: Boolean
        get() = client?.isConnected == true && client?.isAuthenticated == true

    /** server: host:port@user:password. Host/port hanya referensi; socket langsung ke 127.0.0.1:7000 (tunnel dnstt). */
    @Synchronized
    fun prepare(server: String) {
        disconnect()
        val t = parse(server)
        target = t
        val s = DirectSocket()
        try {
            s.connect(InetSocketAddress(LOCAL_HOST, LOCAL_PORT), CONNECT_TIMEOUT_MS)
        } catch (e: Throwable) {
            try { s.close() } catch (_: IOException) {}
            LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
            if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
            throw e
        }
        socket = s
    }

    /** Autentikasi SSHJ (user/pass) memakai socket yang sudah di-proxy. */
    @Synchronized
    fun connect() {
        val t = target ?: throw IllegalStateException("prepare() belum dipanggil")
        val s = socket ?: throw IllegalStateException("socket belum siap")
        net.schmizz.sshj.common.SecurityUtils.setRegisterBouncyCastle(false)
        val config = DefaultConfig()
        config.setKeepAliveProvider(KeepAliveProvider.KEEP_ALIVE)
        val ssh = SSHClient(config)
        try {
            ssh.addHostKeyVerifier(PromiscuousVerifier())
            ssh.setSocketFactory(object : SocketFactory() {
                override fun createSocket(): Socket = s
                override fun createSocket(host: String?, port: Int): Socket = s
                override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket = s
                override fun createSocket(host: InetAddress?, port: Int): Socket = s
                override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket = s
            })
            ssh.connection.keepAlive.setKeepAliveInterval(30) // 30 detik
            // Socket sudah tersambung ke tunnel lokal; alamat ini hanya formalitas SSHJ.
            ssh.connect(InetAddress.getByAddress(LOCAL_HOST, byteArrayOf(127, 0, 0, 1)), LOCAL_PORT)
            LogState.addLog("Server Message: ${ssh.transport.serverVersion}")
            ssh.authPassword(t.user, t.pass)
            LogState.addLog("Auth Complete")
        } catch (e: Throwable) {
            LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
            if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
            try { ssh.disconnect() } catch (_: Throwable) {}
            try { s.close() } catch (_: IOException) {}
            socket = null
            throw e
        }
        client = ssh
    }

    /** Kanal direct-tcpip lewat sesi SSH (API resmi SSHJ). */
    fun open(host: String, port: Int): DirectConnection {
        val ssh = synchronized(this) { client }
        if (ssh == null || !ssh.isConnected || !ssh.isAuthenticated) throw IOException("SSH belum tersambung")
        try {
            return ssh.newDirectConnection(host, port)
        } catch (e: Throwable) {
            throw e
        }
    }

    /** UDPGW: forward lokal 127.0.0.1:port -> 127.0.0.1:port di sisi server lewat sesi SSH (SSHJ). */
    @Synchronized
    fun startUdpgw(port: Int) {
        val ssh = client ?: throw IllegalStateException("SSH belum tersambung")
        stopUdpgw()
        // TCP_NODELAY pada koneksi yang diterima: frame udpgw kecil tidak boleh tertahan Nagle.
        val ss = object : ServerSocket() {
            override fun accept(): Socket {
                val c = super.accept()
                try { c.tcpNoDelay = true } catch (_: Throwable) {}
                return c
            }
        }
        ss.reuseAddress = true
        ss.bind(InetSocketAddress(LOCAL_HOST, port))
        val fwd = ssh.newLocalPortForwarder(Parameters(LOCAL_HOST, port, LOCAL_HOST, port), ss)
        udpgwSocket = ss
        udpgwPort = port
        thread(name = "udpgw-forward", isDaemon = true) {
            try {
                fwd.listen()
            } catch (e: Throwable) {
                if (!ss.isClosed) LogState.addLog("UDPGW berhenti: ${e.message ?: e.javaClass.simpleName}")
            }
        }
        LogState.addLog("UDPGW aktif: 127.0.0.1:$port -> server 127.0.0.1:$port")
    }

    @Synchronized
    private fun stopUdpgw() {
        udpgwPort = 0
        try { udpgwSocket?.close() } catch (_: Throwable) {}
        udpgwSocket = null
    }

    @Synchronized
    fun disconnect() {
        stopUdpgw()
        try { client?.disconnect() } catch (_: Throwable) {}
        try { socket?.close() } catch (_: Throwable) {}
        client = null
        socket = null
    }

    private fun parse(server: String): Target {
        val s = server.trim()
        val at = s.indexOf('@')
        require(at > 0) { "Format server: host:port@user:password" }
        val hostPort = s.substring(0, at)
        val cred = s.substring(at + 1)
        val colon = cred.indexOf(':')
        require(colon > 0) { "Format server: host:port@user:password" }
        val user = cred.substring(0, colon)
        val pass = cred.substring(colon + 1)
        val pc = hostPort.lastIndexOf(':')
        val host = if (pc > 0) hostPort.substring(0, pc) else hostPort
        val port = if (pc > 0) hostPort.substring(pc + 1).toIntOrNull() ?: 22 else 22
        require(host.isNotEmpty()) { "Host kosong" }
        return Target(host, port, user, pass)
    }
}
