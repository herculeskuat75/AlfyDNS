package com.alfydns.app

import net.schmizz.sshj.DefaultConfig
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.connection.keepalive.KeepAliveProvider
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import net.schmizz.sshj.connection.channel.direct.DirectConnection
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.Socket
import java.net.SocketAddress
import javax.net.SocketFactory

object SshLink {

    private const val CONNECT_TIMEOUT_MS = 20_000

    private class Target(val host: String, val port: Int, val user: String, val pass: String)

    /** Socket via proxy; connect() kedua dari SSHJ diabaikan karena sudah tersambung. */
    private class ProxiedSocket(proxy: Proxy) : Socket(proxy) {
        override fun connect(endpoint: SocketAddress, timeout: Int) {
            if (!isConnected) super.connect(endpoint, timeout)
        }
    }

    private var target: Target? = null
    private var socket: Socket? = null
    private var client: SSHClient? = null

    val isConnected: Boolean
        get() = client?.isConnected == true && client?.isAuthenticated == true

    /** server: host:port@user:password. Membuat Socket lewat SOCKS 127.0.0.1:7000 menuju host SSH. */
    @Synchronized
    fun prepare(server: String) {
        disconnect()
        val t = parse(server)
        target = t
        LogState.addLog("SSH: membuka soket via SOCKS 127.0.0.1:7000 -> ${t.host}:${t.port}")
        val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", 7000))
        val s = ProxiedSocket(proxy)
        try {
            s.connect(InetSocketAddress.createUnresolved(t.host, t.port), CONNECT_TIMEOUT_MS)
        } catch (e: Throwable) {
            try { s.close() } catch (_: IOException) {}
            LogState.addLog("SSH: soket gagal: ${describe(e)}")
            throw e
        }
        LogState.addLog("SSH: soket tersambung via proxy")
        socket = s
    }

    /** Autentikasi SSHJ (user/pass) memakai socket yang sudah di-proxy. */
    @Synchronized
    fun connect() {
        val t = target ?: throw IllegalStateException("prepare() belum dipanggil")
        val s = socket ?: throw IllegalStateException("socket belum siap")
        val cfg = DefaultConfig().apply { keepAliveProvider = KeepAliveProvider.KEEP_ALIVE }
        val ssh = SSHClient(cfg)
        LogState.addLog("SSH: handshake & autentikasi user ${t.user}")
        try {
            ssh.addHostKeyVerifier(PromiscuousVerifier())
            ssh.setSocketFactory(object : SocketFactory() {
                override fun createSocket(): Socket = s
                override fun createSocket(host: String?, port: Int): Socket = s
                override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket = s
                override fun createSocket(host: InetAddress?, port: Int): Socket = s
                override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket = s
            })
            // InetAddress dummy bernama host: tanpa lookup DNS lokal, koneksi nyata sudah lewat proxy.
            ssh.connect(InetAddress.getByAddress(t.host, byteArrayOf(0, 0, 0, 0)), t.port)
            ssh.connection.keepAlive.keepAliveInterval = 30
            LogState.addLog("SSH: terhubung, keepalive 30 dtk")
            ssh.authPassword(t.user, t.pass)
            LogState.addLog("SSH: autentikasi sukses")
        } catch (e: Throwable) {
            LogState.addLog("SSH: gagal: ${describe(e)}")
            try { ssh.disconnect() } catch (_: Throwable) {}
            try { s.close() } catch (_: IOException) {}
            socket = null
            throw e
        }
        client = ssh
    }

    /** Kanal direct-tcpip lewat sesi SSH (API resmi SSHJ). */
    fun open(host: String, port: Int): DirectConnection {
        val ssh = synchronized(this) { client }
        if (ssh == null || !ssh.isConnected || !ssh.isAuthenticated) throw IOException("SSH belum tersambung")
        try {
            return ssh.newDirectConnection(host, port)
        } catch (e: Throwable) {
            LogState.addLog("SSH: direct-tcpip $host:$port gagal: ${describe(e)}")
            throw e
        }
    }

    @Synchronized
    fun disconnect() {
        LogState.addLog("SSH: disconnect")
        try { client?.disconnect() } catch (_: Throwable) {}
        try { socket?.close() } catch (_: Throwable) {}
        client = null
        socket = null
    }

    /** Pesan error + rantai penyebab, untuk Log. */
    fun describe(e: Throwable): String {
        val sb = StringBuilder("${e.javaClass.simpleName}: ${e.message}")
        var c = e.cause
        var n = 0
        while (c != null && n < 3) {
            sb.append(" <- ${c.javaClass.simpleName}: ${c.message}")
            c = c.cause
            n++
        }
        return sb.toString()
    }

    private fun parse(server: String): Target {
        val s = server.trim()
        val at = s.indexOf('@')
        require(at > 0) { "Format server: host:port@user:password" }
        val hostPort = s.substring(0, at)
        val cred = s.substring(at + 1)
        val colon = cred.indexOf(':')
        require(colon > 0) { "Format server: host:port@user:password" }
        val user = cred.substring(0, colon)
        val pass = cred.substring(colon + 1)
        val pc = hostPort.lastIndexOf(':')
        val host = if (pc > 0) hostPort.substring(0, pc) else hostPort
        val port = if (pc > 0) hostPort.substring(pc + 1).toIntOrNull() ?: 22 else 22
        require(host.isNotEmpty()) { "Host kosong" }
        return Target(host, port, user, pass)
    }
}
