package com.alfydns.app

import android.content.Context
import com.google.gson.GsonBuilder
import org.json.JSONArray
import org.json.JSONObject

data class Config(
    val id: String,
    val name: String,
    val server: String,
    val resolver: String,
    val ns: String,
    val key: String,
    val dnsType: String = "AUTO",
    val isUdpgwEnabled: Boolean = false,
    val udpgwPort: Int = 7300
)

/** Simpan daftar config (urutan = urutan list) di SharedPreferences sebagai JSON. */
object ConfigStore {
    private const val PREFS = "alfydns"
    private const val K_LIST = "configs"
    private const val K_SEL = "config_selected"

    fun load(ctx: Context): List<Config> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_LIST, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull {
                try {
                    val o = a.getJSONObject(it)
                    Config(
                        o.getString("id"), o.optString("name"), o.optString("server"),
                        o.optString("resolver"), o.optString("ns"), o.optString("key"),
                        o.optString("dnsType", "AUTO"),
                        o.optBoolean("isUdpgwEnabled", false), o.optInt("udpgwPort", 7300)
                    )
                } catch (_: Throwable) { null }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Config>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("server", it.server)
                    .put("resolver", it.resolver).put("ns", it.ns).put("key", it.key).put("dnsType", it.dnsType)
                    .put("isUdpgwEnabled", it.isUdpgwEnabled).put("udpgwPort", it.udpgwPort)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_LIST, a.toString()).commit()
    }

    /** Ekspor daftar config ke JSON (Gson) untuk file backup. */
    fun exportJson(list: List<Config>): String = GsonBuilder().setPrettyPrinting().create().toJson(list)

    /** Impor JSON backup menjadi daftar config; field hilang diisi default, entri tanpa id dibuang. Melempar bila JSON rusak. */
    fun importJson(json: String): List<Config> {
        val arr = GsonBuilder().create().fromJson(json, Array<Config>::class.java) ?: return emptyList()
        return arr.mapNotNull { c ->
            val id = (c.id as String?)?.takeIf { it.isNotBlank() } ?: return@mapNotNull null
            Config(
                id, (c.name as String?) ?: "", (c.server as String?) ?: "", (c.resolver as String?) ?: "",
                (c.ns as String?) ?: "", (c.key as String?) ?: "", (c.dnsType as String?) ?: "AUTO",
                c.isUdpgwEnabled, if (c.udpgwPort in 1..65535) c.udpgwPort else 7300
            )
        }
    }

    fun selectedId(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_SEL, null)

    fun saveSelected(ctx: Context, id: String?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_SEL, id).commit()
    }

    private const val K_UDPGW_ON = "udpgw_enabled"
    private const val K_UDPGW_PORT = "udpgw_port"

    /** Pengaturan UDPGW aktif saat ini (dibaca VpnSvc saat menyambung). */
    fun saveUdpgw(ctx: Context, enabled: Boolean, port: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(K_UDPGW_ON, enabled).putInt(K_UDPGW_PORT, port).commit()
    }

    fun loadUdpgw(ctx: Context): Pair<Boolean, Int> {
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Pair(sp.getBoolean(K_UDPGW_ON, false), sp.getInt(K_UDPGW_PORT, 7300))
    }

    private const val K_DRAFT = "draft_input"

    /** Isi kolom input utama (server, resolver, ns, key) agar tidak hilang saat app ditutup. */
    fun saveDraft(ctx: Context, server: String, resolver: String, ns: String, key: String, dnsType: String = "AUTO") {
        val o = JSONObject().put("server", server).put("resolver", resolver).put("ns", ns).put("key", key).put("dnsType", dnsType)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_DRAFT, o.toString()).commit()
    }

    fun loadDraft(ctx: Context): Config? {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_DRAFT, null) ?: return null
        return try {
            val o = JSONObject(raw)
            Config("", "", o.optString("server"), o.optString("resolver"), o.optString("ns"), o.optString("key"), o.optString("dnsType", "AUTO"))
        } catch (_: Throwable) { null }
    }

    private const val K_VERBOSE = "verbose_log"

    /** Log Detail: false = hanya log penting, true = semua log mentah dnstt. */
    fun isVerboseLogEnabled(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(K_VERBOSE, false)

    fun setVerboseLogEnabled(ctx: Context, enabled: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(K_VERBOSE, enabled).commit()
    }
}
