package com.alfydns.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Config(
    val id: String,
    val name: String,
    val server: String,
    val resolver: String,
    val ns: String,
    val key: String
)

/** Simpan daftar config (urutan = urutan list) di SharedPreferences sebagai JSON. */
object ConfigStore {
    private const val PREFS = "alfydns"
    private const val K_LIST = "configs"
    private const val K_SEL = "config_selected"

    fun load(ctx: Context): List<Config> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_LIST, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull {
                try {
                    val o = a.getJSONObject(it)
                    Config(
                        o.getString("id"), o.optString("name"), o.optString("server"),
                        o.optString("resolver"), o.optString("ns"), o.optString("key")
                    )
                } catch (_: Throwable) { null }
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Config>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("id", it.id).put("name", it.name).put("server", it.server)
                    .put("resolver", it.resolver).put("ns", it.ns).put("key", it.key)
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_LIST, a.toString()).commit()
    }

    fun selectedId(ctx: Context): String? =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_SEL, null)

    fun saveSelected(ctx: Context, id: String?) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_SEL, id).commit()
    }

    private const val K_DRAFT = "draft_input"

    /** Isi kolom input utama (server, resolver, ns, key) agar tidak hilang saat app ditutup. */
    fun saveDraft(ctx: Context, server: String, resolver: String, ns: String, key: String) {
        val o = JSONObject().put("server", server).put("resolver", resolver).put("ns", ns).put("key", key)
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_DRAFT, o.toString()).commit()
    }

    fun loadDraft(ctx: Context): Config? {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K_DRAFT, null) ?: return null
        return try {
            val o = JSONObject(raw)
            Config("", "", o.optString("server"), o.optString("resolver"), o.optString("ns"), o.optString("key"))
        } catch (_: Throwable) { null }
    }
}
