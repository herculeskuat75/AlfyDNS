package com.alfydns.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

object VpnState {
    internal val mutable = MutableStateFlow(VpnStatus.DISCONNECTED)
    val status: StateFlow<VpnStatus> = mutable
}

class VpnSvc : VpnService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            teardown()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundNotification()
        val server = intent?.getStringExtra(EXTRA_SERVER)
        val ns = intent?.getStringExtra(EXTRA_NS)
        val key = intent?.getStringExtra(EXTRA_KEY)
        val resolver = intent?.getStringExtra(EXTRA_RESOLVER)
        if (server == null || ns == null || key == null || resolver == null) {
            teardown()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        job?.cancel()
        job = scope.launch { runTunnel(server, ns, key, resolver) }
        return START_NOT_STICKY
    }

    private suspend fun runTunnel(server: String, ns: String, key: String, resolver: String) {
        VpnState.mutable.value = VpnStatus.CONNECTING
        try {
            DnsttWrapper.start(ns, key, resolver)
            delay(1000)
            DnsttWrapper.error()?.let { throw it }
            SshLink.prepare(server)
            SshLink.connect()
            VpnState.mutable.value = VpnStatus.CONNECTED
            while (scope.isActive && SshLink.isConnected && DnsttWrapper.error() == null) delay(2000)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            Log.e("VpnSvc", "Koneksi gagal", e)
        }
        teardown()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun teardown() {
        SshLink.disconnect()
        DnsttWrapper.stop()
        VpnState.mutable.value = VpnStatus.DISCONNECTED
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        teardown()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openApp)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        const val ACTION_START = "com.alfydns.app.action.START"
        const val ACTION_STOP = "com.alfydns.app.action.STOP"
        const val EXTRA_SERVER = "server"
        const val EXTRA_NS = "ns"
        const val EXTRA_KEY = "key"
        const val EXTRA_RESOLVER = "resolver"
        private const val CHANNEL_ID = "alfydns_vpn"
        private const val NOTIFICATION_ID = 1
    }
}
