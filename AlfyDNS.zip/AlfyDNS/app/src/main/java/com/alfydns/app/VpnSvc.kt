package com.alfydns.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.PowerManager
import android.util.Log
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.IOException

object VpnState {
    internal val mutable = MutableStateFlow(VpnStatus.DISCONNECTED)
    val status: StateFlow<VpnStatus> = mutable
}

class VpnSvc : VpnService() {

    private class Params(val server: String, val ns: String, val key: String, val resolver: String, val dnsType: String = "AUTO")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    @Volatile private var job: Job? = null
    @Volatile private var tun: TunStack? = null
    @Volatile private var fg = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopVpn()
                return START_NOT_STICKY
            }
            ACTION_RECONNECT -> {
                if (last == null) {
                    stopVpn()
                } else {
                    startForegroundNotification(getString(R.string.notif_status_reconnecting))
                    reconnect()
                }
                return START_NOT_STICKY
            }
        }
        startForegroundNotification(getString(R.string.notif_status_connecting))
        val server = intent?.getStringExtra(EXTRA_SERVER)
        val ns = intent?.getStringExtra(EXTRA_NS)
        val key = intent?.getStringExtra(EXTRA_KEY)
        val resolver = intent?.getStringExtra(EXTRA_RESOLVER)
        val dnsType = intent?.getStringExtra(EXTRA_DNSTYPE) ?: "AUTO"
        if (server == null || ns == null || key == null || resolver == null) {
            stopVpn()
            return START_NOT_STICKY
        }
        last = Params(server, ns, key, resolver, dnsType)
        launchTunnel()
        return START_NOT_STICKY
    }

    /** Mulai (atau mulai ulang) seluruh rantai DNSTT -> SSH -> TUN memakai parameter terakhir. */
    @Synchronized
    private fun launchTunnel() {
        val p = last ?: return
        val old = job
        old?.cancel()
        acquireWakeLock()
        job = scope.launch {
            if (old != null) {
                teardownNetwork()
                old.join()
                delay(500)
            }
            runTunnel(p)
        }
    }

    /** Dipanggil dari notifikasi (tombol SAMBUNG ULANG) dan dari watchdog. */
    fun reconnect() {
        if (last == null) return
        setStatus(VpnStatus.CONNECTING, getString(R.string.notif_status_reconnecting))
        launchTunnel()
    }

    /** Dipanggil dari notifikasi (tombol PUTUS) dan dari MainActivity (ACTION_STOP). */
    fun stopVpn() {
        VpnState.mutable.value = VpnStatus.DISCONNECTED
        fg = false
        val old = job
        job = null
        old?.cancel()
        scope.launch {
            teardown()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun runTunnel(p: Params) {
        setStatus(VpnStatus.CONNECTING, getString(R.string.notif_status_connecting))
        LogState.addLog("Menyambungkan...")
        try {
            DnsttWrapper.start(p.ns, p.key, p.resolver, when (p.dnsType.uppercase()) { "NULL" -> "NULL"; "TXT" -> "TXT"; else -> "AUTO" })
            waitForPort("127.0.0.1", 7000, 10_000)
            SshLink.prepare(p.server)
            SshLink.connect()
            try {
                startTun()
            } catch (e: Throwable) {
                LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
                if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
                throw e
            }
            setStatus(VpnStatus.CONNECTED, getString(R.string.notif_status_connected))
            LogState.addLog("Connected")
            coroutineScope {
                val wd = launch { watchdog() }
                while (isActive && SshLink.isConnected && DnsttWrapper.error() == null) delay(2000)
                wd.cancel()
            }
            // Tautan putus saat sudah terhubung: sambung ulang otomatis.
            currentCoroutineContext().ensureActive()
            Log.w(TAG, "Tautan terputus, menyambung ulang")
            LogState.addLog("Gagal: Koneksi terputus")
            delay(5000)
            reconnect()
            return
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            currentCoroutineContext().ensureActive()
            Log.e(TAG, "Koneksi gagal", e)
        }
        stopVpn()
    }

    /** Tunggu sampai port lokal DNSTT menerima koneksi; hentikan bila DNSTT error atau timeout. */
    private suspend fun waitForPort(host: String, port: Int, timeoutMs: Long) {
        val end = System.currentTimeMillis() + timeoutMs
        while (true) {
            DnsttWrapper.error()?.let { throw it }
            val ok = withContext(Dispatchers.IO) {
                try {
                    java.net.Socket().use { it.connect(java.net.InetSocketAddress(host, port), 500) }
                    true
                } catch (e: IOException) {
                    false
                }
            }
            if (ok) return
            if (System.currentTimeMillis() >= end) {
                LogState.addLog("DNSTT gagal start")
                throw IOException("DNSTT gagal start")
            }
            delay(300)
        }
    }

    private fun startTun() {
        val builder = Builder()
            .setSession("AlfyDNS")
            .setMtu(1280)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("8.8.4.4")
            .setBlocking(true)
        try {
            builder.addDisallowedApplication(packageName)
        } catch (e: Exception) {
            Log.w(TAG, "addDisallowedApplication gagal", e)
        }
        val pfd = builder.establish() ?: throw IOException("Gagal membuat antarmuka TUN")
        val stack = TunStack(pfd)
        tun = stack
        stack.start()
    }

    /** Tes TCP 8.8.8.8:53 lewat terowongan SSH tiap 10 detik; 2x gagal beruntun -> mode pesawat (root) lalu reconnect. */
    private suspend fun watchdog() {
        var fails = 0
        while (true) {
            delay(10_000)
            if (tunnelPing()) {
                fails = 0
            } else {
                fails++
                Log.w(TAG, "Tes terowongan gagal ($fails/2)")
                if (fails >= 2) {
                    LogState.addLog("Gagal: Terowongan tidak merespons")
                    airplaneReset()
                    delay(5000)
                    reconnect()
                    return
                }
            }
        }
    }

    /** Reset radio via root; tanpa root hanya gagal diam-diam. */
    private suspend fun airplaneReset() {
        try {
            suCmd("cmd connectivity airplane-mode enable")
            delay(2000)
            suCmd("cmd connectivity airplane-mode disable")
            delay(3000)
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
        }
    }

    private suspend fun suCmd(cmd: String) = withContext(Dispatchers.IO) {
        val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        try {
            withTimeoutOrNull(5000) { runInterruptible { proc.waitFor() } }
        } finally {
            proc.destroy()
        }
    }

    private suspend fun tunnelPing(): Boolean = withContext(Dispatchers.IO) {
        try {
            withTimeoutOrNull(8000) {
                runInterruptible {
                    SshLink.open("8.8.8.8", 53).use { true }
                }
            } == true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            false
        }
    }

    private fun teardownNetwork() {
        val t = tun
        tun = null
        try { t?.stop() } catch (_: Throwable) {}
        SshLink.disconnect()
        DnsttWrapper.stop()
    }

    private fun teardown() {
        teardownNetwork()
        releaseWakeLock()
        VpnState.mutable.value = VpnStatus.DISCONNECTED
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        fg = false
        job?.cancel()
        scope.cancel()
        teardown()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- WakeLock

    @Synchronized
    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlfyDNS:vpn").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    @Synchronized
    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Throwable) {}
        wakeLock = null
    }

    // ---------------------------------------------------------------- Notifikasi

    private fun setStatus(status: VpnStatus, text: String) {
        VpnState.mutable.value = status
        if (fg) {
            getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(text))
        }
    }

    private fun actionIntent(action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            this,
            requestCode,
            Intent(this, NotifReceiver::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun buildNotification(statusText: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val views = RemoteViews(packageName, R.layout.notif_vpn).apply {
            setTextViewText(R.id.notif_title, getString(R.string.notif_title))
            setTextViewText(R.id.notif_status, statusText)
            setOnClickPendingIntent(R.id.btn_stop, actionIntent(ACTION_STOP, 1))
            setOnClickPendingIntent(R.id.btn_reconnect, actionIntent(ACTION_RECONNECT, 2))
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(statusText)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(views)
            .setCustomBigContentView(views)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun startForegroundNotification(statusText: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = buildNotification(statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        fg = true
    }

    companion object {
        const val ACTION_START = "com.alfydns.app.action.START"
        const val ACTION_STOP = "com.alfydns.app.action.STOP"
        const val ACTION_RECONNECT = "com.alfydns.app.action.RECONNECT"
        const val EXTRA_SERVER = "server"
        const val EXTRA_NS = "ns"
        const val EXTRA_KEY = "key"
        const val EXTRA_RESOLVER = "resolver"
        const val EXTRA_DNSTYPE = "dnsType"
        private const val TAG = "VpnSvc"
        private const val CHANNEL_ID = "alfydns_vpn"
        private const val NOTIFICATION_ID = 1

        @Volatile internal var instance: VpnSvc? = null
        @Volatile private var last: Params? = null

        /** Dipakai NotifReceiver bila service sudah mati: kirim ulang START dengan parameter terakhir. */
        internal fun restartIntent(ctx: Context): Intent? {
            val p = last ?: return null
            return Intent(ctx, VpnSvc::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_SERVER, p.server)
                .putExtra(EXTRA_NS, p.ns)
                .putExtra(EXTRA_KEY, p.key)
                .putExtra(EXTRA_RESOLVER, p.resolver)
                .putExtra(EXTRA_DNSTYPE, p.dnsType)
        }
    }
}
