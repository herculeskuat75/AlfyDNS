package com.alfydns.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Card
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class VpnStatus(val label: String) {
    DISCONNECTED("Terputus"),
    CONNECTING("Menghubungkan..."),
    CONNECTED("Terhubung")
}

private val GreenConnect = Color(0xFF2E7D32)
private val RedDisconnect = Color(0xFFC62828)

@Composable
fun MainScreen(
    status: VpnStatus,
    onConnect: (server: String, resolver: String, ns: String, key: String, dnsType: String) -> Unit,
    onDisconnect: () -> Unit,
    background: ImageBitmap? = null,
    onPickBackground: () -> Unit = {},
    onClearBackground: () -> Unit = {}
) {
    val appCtx = LocalContext.current
    val configs = remember { mutableStateListOf<Config>().apply { addAll(ConfigStore.load(appCtx)) } }
    var selectedId by remember { mutableStateOf(ConfigStore.selectedId(appCtx)) }
    val initial = ConfigStore.loadDraft(appCtx) ?: configs.firstOrNull { it.id == selectedId }
    var server by rememberSaveable { mutableStateOf(initial?.server ?: "") }
    var dnsResolver by rememberSaveable { mutableStateOf(initial?.resolver ?: "") }
    var nsServer by rememberSaveable { mutableStateOf(initial?.ns ?: "") }
    var publicKey by rememberSaveable { mutableStateOf(initial?.key ?: "") }
    var dnsType by rememberSaveable { mutableStateOf(initial?.dnsType ?: "AUTO") }
    var dnsTypeMenu by remember { mutableStateOf(false) }
    LaunchedEffect(server, dnsResolver, nsServer, publicKey, dnsType) {
        ConfigStore.saveDraft(appCtx, server, dnsResolver, nsServer, publicKey, dnsType)
    }
    val udpgw0 = remember { ConfigStore.loadUdpgw(appCtx) }
    var udpgwEnabled by rememberSaveable { mutableStateOf(udpgw0.first) }
    var udpgwPort by rememberSaveable { mutableStateOf(udpgw0.second.toString()) }
    LaunchedEffect(udpgwEnabled, udpgwPort) {
        ConfigStore.saveUdpgw(appCtx, udpgwEnabled, udpgwPort.toIntOrNull()?.takeIf { it in 1..65535 } ?: 7300)
    }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerScope = rememberCoroutineScope()

    val logs by LogState.logs.collectAsState()
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val logState = rememberLazyListState()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) logState.scrollToItem(logs.size - 1) }

    var backupMenu by remember { mutableStateOf(false) }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                appCtx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(ConfigStore.exportJson(configs.toList()).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(appCtx, "Backup tersimpan (${configs.size} config)", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
                Toast.makeText(appCtx, "Backup gagal: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val json = appCtx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                val imported = ConfigStore.importJson(json)
                // Gabungkan: id sama ditimpa, id baru ditambahkan.
                imported.forEach { c ->
                    val i = configs.indexOfFirst { it.id == c.id }
                    if (i >= 0) configs[i] = c else configs.add(c)
                }
                ConfigStore.save(appCtx, configs.toList())
                configs.firstOrNull { it.id == selectedId }?.let { c ->
                    udpgwEnabled = c.isUdpgwEnabled; udpgwPort = c.udpgwPort.toString()
                    server = c.server; dnsResolver = c.resolver; nsServer = c.ns; publicKey = c.key; dnsType = c.dnsType
                }
                Toast.makeText(appCtx, "Restore selesai (${imported.size} config)", Toast.LENGTH_SHORT).show()
            } catch (e: Throwable) {
                Toast.makeText(appCtx, "Restore gagal: file tidak valid", Toast.LENGTH_LONG).show()
            }
        }
    }

    MaterialTheme(colorScheme = if (background != null) darkColorScheme() else lightColorScheme()) {
      ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet {
                ConfigPanel(
                    configs = configs,
                    selectedId = selectedId,
                    connected = status == VpnStatus.CONNECTED,
                    draft = Config("", "", server, dnsResolver, nsServer, publicKey, dnsType),
                    onSelect = { c ->
                        selectedId = c.id
                        ConfigStore.saveSelected(appCtx, c.id)
                        udpgwEnabled = c.isUdpgwEnabled; udpgwPort = c.udpgwPort.toString()
                        server = c.server; dnsResolver = c.resolver; nsServer = c.ns; publicKey = c.key; dnsType = c.dnsType
                        drawerScope.launch { drawerState.close() }
                    },
                    onSave = { c0 ->
                        val old = configs.firstOrNull { it.id == c0.id }
                        val c = c0.copy(
                            isUdpgwEnabled = if (c0.id == selectedId) udpgwEnabled else (old?.isUdpgwEnabled ?: udpgwEnabled),
                            udpgwPort = if (c0.id == selectedId) (udpgwPort.toIntOrNull()?.takeIf { it in 1..65535 } ?: 7300) else (old?.udpgwPort ?: (udpgwPort.toIntOrNull()?.takeIf { it in 1..65535 } ?: 7300))
                        )
                        val i = configs.indexOfFirst { it.id == c.id }
                        if (i >= 0) configs[i] = c else configs.add(c)
                        ConfigStore.save(appCtx, configs.toList())
                        if (c.id == selectedId) {
                            server = c.server; dnsResolver = c.resolver; nsServer = c.ns; publicKey = c.key; dnsType = c.dnsType
                        }
                    },
                    onDelete = { c ->
                        configs.removeAll { it.id == c.id }
                        if (selectedId == c.id) { selectedId = null; ConfigStore.saveSelected(appCtx, null) }
                        ConfigStore.save(appCtx, configs.toList())
                    },
                    onMove = { from, to ->
                        if (from in configs.indices && to in configs.indices) configs.add(to, configs.removeAt(from))
                    },
                    onReorderEnd = { ConfigStore.save(appCtx, configs.toList()) }
                )
            }
        }
      ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = if (background != null) Color.Transparent else MaterialTheme.colorScheme.background
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            if (background != null) {
                Image(
                    bitmap = background,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)))
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(
                        text = "AlfyDNS",
                        color = if (background != null) Color.White else Color.Unspecified,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Box {
                        TextButton(onClick = { backupMenu = true }) { Text("⋮") }
                        DropdownMenu(expanded = backupMenu, onDismissRequest = { backupMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Backup ke File") },
                                onClick = {
                                    backupMenu = false
                                    backupLauncher.launch(SimpleDateFormat("dd_MM_yyyy", Locale.US).format(Date()) + "_alfydns.backup")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Restore dari File") },
                                onClick = {
                                    backupMenu = false
                                    restoreLauncher.launch(arrayOf("*/*"))
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = server,
                    onValueChange = { server = it.replace("\n", "").replace("\r", "") },
                    label = { Text("Server (host:port@user:password)") },
                    minLines = 1,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dnsResolver,
                    onValueChange = { dnsResolver = it.replace("\n", "").replace("\r", "") },
                    label = { Text("DNS Resolver") },
                    minLines = 1,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { dnsTypeMenu = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Tipe DNS: " + when (dnsType) {
                                "TXT" -> "TXT"
                                "NULL" -> "NULL"
                                else -> "Otomatis (NULL/TXT)"
                            }
                        )
                    }
                    DropdownMenu(expanded = dnsTypeMenu, onDismissRequest = { dnsTypeMenu = false }) {
                        DropdownMenuItem(text = { Text("Otomatis (NULL/TXT)") }, onClick = { dnsType = "AUTO"; dnsTypeMenu = false })
                        DropdownMenuItem(text = { Text("TXT") }, onClick = { dnsType = "TXT"; dnsTypeMenu = false })
                        DropdownMenuItem(text = { Text("NULL") }, onClick = { dnsType = "NULL"; dnsTypeMenu = false })
                    }
                }
                OutlinedTextField(
                    value = nsServer,
                    onValueChange = { nsServer = it.replace("\n", "").replace("\r", "") },
                    label = { Text("NS Server") },
                    minLines = 1,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = publicKey,
                    onValueChange = { publicKey = it.replace("\n", "").replace("\r", "") },
                    label = { Text("Public Key") },
                    minLines = 1,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Aktifkan UDPGW",
                        color = if (background != null) Color.White else Color.Unspecified,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(checked = udpgwEnabled, onCheckedChange = { udpgwEnabled = it })
                }
                OutlinedTextField(
                    value = udpgwPort,
                    onValueChange = { udpgwPort = it.filter { ch -> ch.isDigit() }.take(5) },
                    label = { Text("Port UDPGW") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = { onConnect(server, dnsResolver, nsServer, publicKey, dnsType) },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenConnect),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                ) {
                    Text("KONEK", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onDisconnect,
                    colors = ButtonDefaults.buttonColors(containerColor = RedDisconnect),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                ) {
                    Text("PUTUS", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onPickBackground, modifier = Modifier.weight(1f)) {
                        Text("Ganti Background")
                    }
                    OutlinedButton(onClick = onClearBackground, modifier = Modifier.weight(1f)) {
                        Text("Hapus Background")
                    }
                }

                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(logs.joinToString("\n")))
                        Toast.makeText(ctx, "Log disalin", Toast.LENGTH_SHORT).show()
                    }) { Text("Salin Log", fontSize = 12.sp) }
                    TextButton(onClick = { LogState.clearLog() }) { Text("Bersihkan", fontSize = 12.sp) }
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    LazyColumn(
                        state = logState,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).padding(8.dp)
                    ) {
                        items(logs) { line -> Text(line, fontSize = 11.sp, lineHeight = 14.sp, color = if (line.endsWith("Connected") && !line.contains("Gagal")) Color(0xFF2E7D32) else Color.Unspecified) }
                    }
                }

                Text(
                    text = status.label,
                    color = if (background != null) Color.White else Color.Unspecified,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth()
                )
            }
          }
        }
      }
    }
}
