package com.alfydns.app

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.material3.Card
import androidx.compose.material3.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.OutlinedButton
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class VpnStatus(val label: String) {
    DISCONNECTED("Terputus"),
    CONNECTING("Menghubungkan..."),
    CONNECTED("Terhubung")
}

private val GreenConnect = Color(0xFF2E7D32)
private val RedDisconnect = Color(0xFFC62828)

@Composable
fun MainScreen(
    status: VpnStatus,
    onConnect: (server: String, resolver: String, ns: String, key: String) -> Unit,
    onDisconnect: () -> Unit,
    background: ImageBitmap? = null,
    onPickBackground: () -> Unit = {},
    onClearBackground: () -> Unit = {}
) {
    var server by rememberSaveable { mutableStateOf("") }
    var dnsResolver by rememberSaveable { mutableStateOf("") }
    var nsServer by rememberSaveable { mutableStateOf("") }
    var publicKey by rememberSaveable { mutableStateOf("") }

    val logs by LogState.logs.collectAsState()
    val clipboard = LocalClipboardManager.current
    val ctx = LocalContext.current
    val logState = rememberLazyListState()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) logState.scrollToItem(logs.size - 1) }

    MaterialTheme(colorScheme = if (background != null) darkColorScheme() else lightColorScheme()) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = if (background != null) Color.Transparent else MaterialTheme.colorScheme.background
        ) {
          Box(modifier = Modifier.fillMaxSize()) {
            if (background != null) {
                Image(
                    bitmap = background,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)))
            }
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "AlfyDNS",
                    color = if (background != null) Color.White else Color.Unspecified,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = server,
                    onValueChange = { server = it },
                    label = { Text("Server (host:port@user:password)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dnsResolver,
                    onValueChange = { dnsResolver = it },
                    label = { Text("DNS Resolver") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = nsServer,
                    onValueChange = { nsServer = it },
                    label = { Text("NS Server") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = publicKey,
                    onValueChange = { publicKey = it },
                    label = { Text("Public Key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = { onConnect(server, dnsResolver, nsServer, publicKey) },
                    colors = ButtonDefaults.buttonColors(containerColor = GreenConnect),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                ) {
                    Text("KONEK", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onDisconnect,
                    colors = ButtonDefaults.buttonColors(containerColor = RedDisconnect),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                ) {
                    Text("PUTUS", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onPickBackground, modifier = Modifier.weight(1f)) {
                        Text("Ganti Background")
                    }
                    OutlinedButton(onClick = onClearBackground, modifier = Modifier.weight(1f)) {
                        Text("Hapus Background")
                    }
                }

                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = {
                        clipboard.setText(AnnotatedString(logs.joinToString("\n")))
                        Toast.makeText(ctx, "Log disalin", Toast.LENGTH_SHORT).show()
                    }) { Text("Salin Log", fontSize = 12.sp) }
                    TextButton(onClick = { LogState.clearLog() }) { Text("Bersihkan", fontSize = 12.sp) }
                }
                Card(modifier = Modifier.fillMaxWidth()) {
                    LazyColumn(
                        state = logState,
                        modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp).padding(8.dp)
                    ) {
                        items(logs) { line -> Text(line, fontSize = 11.sp, lineHeight = 14.sp) }
                    }
                }

                Text(
                    text = status.label,
                    color = if (background != null) Color.White else Color.Unspecified,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.fillMaxWidth()
                )
            }
          }
        }
    }
}
