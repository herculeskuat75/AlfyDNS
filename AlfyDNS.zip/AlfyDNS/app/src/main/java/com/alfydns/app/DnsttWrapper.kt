package com.alfydns.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

object DnsttWrapper {

    const val LISTEN_ADDR = "127.0.0.1:7000"
    private const val TAG = "DnsttWrapper"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var process: Process? = null
    @Volatile private var job: Job? = null
    @Volatile private var startError: Throwable? = null
    @Volatile private var stopping = false

    /** Konteks aplikasi (tanpa mengubah signature start()). */
    private fun appContext(): Context? = try {
        val at = Class.forName("android.app.ActivityThread")
        at.getMethod("currentApplication").invoke(null) as? Context
    } catch (e: Throwable) {
        Log.e(TAG, "Context tidak tersedia", e)
        null
    }

    // Nama flag record type pada binary AutoSC tidak terdokumentasi: dicoba berurutan, terakhir tanpa flag (AUTO).
    private val RECORD_FLAGS = listOf<String?>("-record", "-sc-record", "-type", "-rr", null)

    private class Run(val code: Int, val early: String, val quick: Boolean)

    /** server = tunnel domain (NS Server), resolver = DNS resolver. Berjalan di background. */
    fun start(server: String, publicKey: String, resolver: String, dnsType: String = "TXT") {
        stop()
        startError = null
        stopping = false
        job = scope.launch {
            LogState.addLog("Menerima tipe DNS: $dnsType (dipaksa NULL)")
            try {
                val ctx = appContext() ?: throw IOException("Context aplikasi tidak tersedia")
                val bin = File(ctx.applicationInfo.nativeLibraryDir, "libdnstt.so")
                if (!bin.exists()) throw IOException("libdnstt.so tidak ditemukan di ${bin.parent}")
                var portless = true
                var i = 0
                while (isActive && !stopping && i < RECORD_FLAGS.size) {
                    val flag = RECORD_FLAGS[i]
                    val cmd = ArrayList<String>()
                    cmd.add(bin.absolutePath)
                    cmd.addAll(resolverArgs(resolver, portless))
                    cmd.add("-pubkey"); cmd.add(publicKey.trim())
                    if (flag != null) { cmd.add(flag); cmd.add("NULL") }
                    cmd.add(server.trim()); cmd.add(LISTEN_ADDR)
                    LogState.addLog("Perintah: ${cmd.joinToString(" ")}")
                    val r = runOnce(cmd)
                    if (stopping || !isActive) return@launch
                    if (r.quick && flag != null && r.early.contains("not defined")) {
                        LogState.addLog("Flag $flag tidak dikenali, coba berikutnya.")
                        i++
                        continue
                    }
                    if (r.quick && portless && r.early.contains("missing port")) {
                        LogState.addLog("Resolver butuh port, ulangi dengan :53.")
                        portless = false
                        continue
                    }
                    LogState.addLog("dnstt berhenti (exit ${r.code}).")
                    startError = IOException("dnstt-client berhenti (exit ${r.code})")
                    return@launch
                }
            } catch (e: Throwable) {
                if (stopping) return@launch
                Log.e(TAG, "DNSTT gagal", e)
                LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
                if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
                startError = e
            }
        }
    }

    /** Jalankan satu proses, alirkan output ke LogState, kembalikan exit code dan output awal. */
    private fun CoroutineScope.runOnce(cmd: List<String>): Run {
        val t0 = System.currentTimeMillis()
        val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
        process = p
        if (!isActive) {
            p.destroy()
            return Run(-1, "", false)
        }
        val early = StringBuilder()
        p.inputStream.bufferedReader().use { r ->
            while (true) {
                val line = r.readLine() ?: break
                if (early.length < 4096) early.append(line).append('\n')
                if (line.isNotBlank()) LogState.addLog("dnstt: $line")
            }
        }
        val code = p.waitFor()
        return Run(code, early.toString(), System.currentTimeMillis() - t0 < 5000 && code != 0)
    }

    /** Resolver -> flag dnstt-client: https:// = -doh, tls:// = -dot, selain itu -udp. */
    private fun resolverArgs(r: String, portless: Boolean): List<String> {
        val s = r.trim()
        return when {
            s.startsWith("https://", true) -> listOf("-doh", s)
            s.startsWith("tls://", true) -> listOf("-dot", withPort(s.substring(6), 853))
            s.startsWith("udp://", true) -> listOf("-udp", udpAddr(s.substring(6), portless))
            s.startsWith("tcp://", true) -> listOf("-udp", udpAddr(s.substring(6), portless))
            else -> listOf("-udp", udpAddr(s, portless))
        }
    }

    /** portless: buang :53 (IP saja); selain itu pastikan ada port. */
    private fun udpAddr(r: String, portless: Boolean): String {
        val s = r.trim()
        if (!portless) return withPort(s, 53)
        if (s.startsWith("[")) return if (s.endsWith("]:53")) s.dropLast(3) else s
        return if (s.count { it == ':' } == 1 && s.endsWith(":53")) s.dropLast(3) else s
    }

    /** IP/host polos -> tambah port default; yang sudah ada port dibiarkan. */
    private fun withPort(r: String, port: Int): String {
        val s = r.trim()
        if (s.startsWith("[")) return if (s.contains("]:")) s else "$s:$port"
        return when (s.count { it == ':' }) {
            0 -> "$s:$port"
            1 -> s
            else -> "[$s]:$port"
        }
    }

    fun error(): Throwable? = startError

    fun isRunning(): Boolean = process?.isAlive ?: false

    fun stop() {
        stopping = true
        job?.cancel()
        job = null
        val p = process
        process = null
        if (p != null) {
            try {
                p.destroy()
                if (p.isAlive) p.destroyForcibly()
            } catch (e: Throwable) {
                Log.w(TAG, "stop gagal", e)
            }
        }
    }
}
