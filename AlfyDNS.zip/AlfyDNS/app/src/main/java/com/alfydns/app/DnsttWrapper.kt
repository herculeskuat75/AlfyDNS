package com.alfydns.app

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException

object DnsttWrapper {

    const val LISTEN_ADDR = "127.0.0.1:7000"
    private const val TAG = "DnsttWrapper"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var process: Process? = null
    @Volatile private var job: Job? = null
    @Volatile private var startError: Throwable? = null
    @Volatile private var stopping = false

    /** Konteks aplikasi (tanpa mengubah signature start()). */
    private fun appContext(): Context? = try {
        val at = Class.forName("android.app.ActivityThread")
        at.getMethod("currentApplication").invoke(null) as? Context
    } catch (e: Throwable) {
        Log.e(TAG, "Context tidak tersedia", e)
        null
    }

    /** server = tunnel domain (NS Server), resolver = DNS resolver. Berjalan di background. */
    fun start(server: String, publicKey: String, resolver: String, dnsType: String = "TXT") {
        stop()
        startError = null
        stopping = false
        job = scope.launch {
            LogState.addLog("Menerima tipe DNS: $dnsType")
            try {
                val ctx = appContext() ?: throw IOException("Context aplikasi tidak tersedia")
                val bin = File(ctx.applicationInfo.nativeLibraryDir, "libdnstt.so")
                if (!bin.exists()) throw IOException("libdnstt.so tidak ditemukan di ${bin.parent}")
                val cmd = ArrayList<String>()
                cmd.add(bin.absolutePath)
                cmd.addAll(resolverArgs(resolver))
                cmd.add("-pubkey"); cmd.add(publicKey.trim())
                cmd.add(server.trim()); cmd.add(LISTEN_ADDR)
                LogState.addLog("Menjalankan dnstt-client.")
                val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
                process = p
                if (!isActive) {
                    p.destroy()
                    return@launch
                }
                p.inputStream.bufferedReader().use { r ->
                    while (true) {
                        val line = r.readLine() ?: break
                        if (line.isNotBlank()) LogState.addLog("dnstt: $line")
                    }
                }
                val code = p.waitFor()
                if (!stopping) {
                    LogState.addLog("dnstt berhenti (exit $code).")
                    startError = IOException("dnstt-client berhenti (exit $code)")
                }
            } catch (e: Throwable) {
                if (stopping) return@launch
                Log.e(TAG, "DNSTT gagal", e)
                LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
                if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
                startError = e
            }
        }
    }

    /** Resolver -> flag dnstt-client: https:// = -doh, tls:// = -dot, selain itu -udp (default :53). */
    private fun resolverArgs(r: String): List<String> {
        val s = r.trim()
        return when {
            s.startsWith("https://", true) -> listOf("-doh", s)
            s.startsWith("tls://", true) -> listOf("-dot", withPort(s.substring(6), 853))
            s.startsWith("udp://", true) -> listOf("-udp", withPort(s.substring(6), 53))
            s.startsWith("tcp://", true) -> listOf("-udp", withPort(s.substring(6), 53))
            else -> listOf("-udp", withPort(s, 53))
        }
    }

    /** IP/host polos -> tambah port default; yang sudah ada port dibiarkan. */
    private fun withPort(r: String, port: Int): String {
        val s = r.trim()
        if (s.startsWith("[")) return if (s.contains("]:")) s else "$s:$port"
        return when (s.count { it == ':' }) {
            0 -> "$s:$port"
            1 -> s
            else -> "[$s]:$port"
        }
    }

    fun error(): Throwable? = startError

    fun isRunning(): Boolean = process?.isAlive ?: false

    fun stop() {
        stopping = true
        job?.cancel()
        job = null
        val p = process
        process = null
        if (p != null) {
            try {
                p.destroy()
                if (p.isAlive) p.destroyForcibly()
            } catch (e: Throwable) {
                Log.w(TAG, "stop gagal", e)
            }
        }
    }
}
