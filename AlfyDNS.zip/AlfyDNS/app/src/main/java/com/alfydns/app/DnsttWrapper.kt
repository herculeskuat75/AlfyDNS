package com.alfydns.app

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import vaydns.Vaydns
import vaydns.VaydnsClient

object DnsttWrapper {

    const val LISTEN_ADDR = "127.0.0.1:7000"
    private const val TAG = "DnsttWrapper"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var client: VaydnsClient? = null
    @Volatile private var job: Job? = null
    @Volatile private var startError: Throwable? = null

    /** server = tunnel domain (NS Server), resolver = DNS resolver. Berjalan di background. */
    fun start(server: String, publicKey: String, resolver: String, dnsType: String = "TXT") {
        stop()
        startError = null
        job = scope.launch {
            LogState.addLog("Menerima tipe DNS: $dnsType")
            val udpAddr = withPort(resolver)
            var c: VaydnsClient? = null
            try {
                if (c == null) c = Vaydns.newClient(udpAddr, server, publicKey, LISTEN_ADDR)
                if (!isActive) {
                    c?.stop()
                    return@launch
                }
                client = c
                if (dnsType.uppercase() == "AUTO") {
                    val modes = listOf(
                        Triple(true, "NULL", "DNSTT-Compat (NULL)"),
                        Triple(true, "TXT", "DNSTT-Compat (TXT)")
                    )
                    var lastErr: Throwable? = null
                    var ok = false
                    for ((i, m) in modes.withIndex()) {
                        if (!isActive) return@launch
                        try {
                            if (i > 0) {
                                try { c?.stop() } catch (_: Throwable) {}
                                delay(1000)
                                if (!isActive) return@launch
                                c = Vaydns.newClient(udpAddr, server, publicKey, LISTEN_ADDR)
                                client = c
                            }
                            LogState.addLog((if (i == 0) "Mencoba mode " else "Gagal, mencoba mode ") + m.third + "...")
                            c?.setDnsttCompat(m.first)
                            c?.setRecordType(m.second)
                            c?.setMaxQnameLen(63L)
                            c?.setClientIDSize(1L)
                            applyFingerprint(c)
                            c?.start()
                            ok = true
                            break
                        } catch (e: Throwable) {
                            Log.w(TAG, "Mode ${m.third} gagal", e)
                            lastErr = e
                        }
                    }
                    if (!ok) throw (lastErr ?: IllegalStateException("Semua mode gagal"))
                } else {
                    c?.setDnsttCompat(true)
                    c?.setRecordType(dnsType.uppercase())
                    c?.setMaxQnameLen(63L)
                    c?.setClientIDSize(1L)
                    applyFingerprint(c)
                    c?.start()
                }
            } catch (e: Throwable) {
                Log.e(TAG, "DNSTT gagal", e)
                LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
                if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
                startError = e
            }
        }
    }

    private fun applyFingerprint(c: VaydnsClient?) {
        try {
            c?.setUTLSFingerprint("chrome")
        } catch (e: Throwable) {
            Log.w(TAG, "uTLS fingerprint gagal", e)
            LogState.addLog("uTLS fingerprint tidak diterapkan: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** IP/host polos -> tambah :53; yang sudah ada port atau URL (https://...) dibiarkan. */
    private fun withPort(r: String): String {
        val s = r.trim()
        if (s.contains("://")) return s
        if (s.startsWith("[")) return if (s.contains("]:")) s else "$s:53"
        return when (s.count { it == ':' }) {
            0 -> "$s:53"
            1 -> s
            else -> "[$s]:53"
        }
    }

    fun error(): Throwable? = startError

    fun isRunning(): Boolean = client?.isRunning ?: false

    fun stop() {
        job?.cancel()
        job = null
        val c = client
        client = null
        if (c != null) {
            try {
                c?.stop()
            } catch (e: Throwable) {
                Log.w(TAG, "stop gagal", e)
            }
        }
    }
}
