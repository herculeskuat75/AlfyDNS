package com.alfydns.app

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import mobile.DnsttClient
import mobile.Mobile

object DnsttWrapper {

    const val LISTEN_ADDR = "127.0.0.1:7000"
    private const val TAG = "DnsttWrapper"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var client: DnsttClient? = null
    @Volatile private var job: Job? = null
    @Volatile private var startError: Throwable? = null

    /** server = tunnel domain (NS Server), resolver = DNS resolver. Berjalan di background. */
    fun start(server: String, publicKey: String, resolver: String) {
        stop()
        startError = null
        job = scope.launch {
            try {
                val c = Mobile.newClient(resolver, server, publicKey, LISTEN_ADDR)
                if (!isActive) {
                    c.stop()
                    return@launch
                }
                client = c
                c.start()
            } catch (e: Throwable) {
                Log.e(TAG, "DNSTT gagal", e)
                startError = e
            }
        }
    }

    fun error(): Throwable? = startError

    fun isRunning(): Boolean = client?.isRunning ?: false

    fun stop() {
        job?.cancel()
        job = null
        val c = client
        client = null
        if (c != null) {
            try {
                c.stop()
            } catch (e: Throwable) {
                Log.w(TAG, "stop gagal", e)
            }
        }
    }
}
