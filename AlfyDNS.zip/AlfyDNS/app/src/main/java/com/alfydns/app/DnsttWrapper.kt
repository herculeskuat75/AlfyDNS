package com.alfydns.app

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import vaydns.Vaydns
import vaydns.VaydnsClient

object DnsttWrapper {

    const val LISTEN_ADDR = "127.0.0.1:7000"
    private const val TAG = "DnsttWrapper"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var client: VaydnsClient? = null
    @Volatile private var job: Job? = null
    @Volatile private var startError: Throwable? = null

    /** server = tunnel domain (NS Server), resolver = DNS resolver. Berjalan di background. */
    fun start(server: String, publicKey: String, resolver: String, dnsType: String = "TXT") {
        stop()
        startError = null
        job = scope.launch {
            val udpAddr = withPort(resolver)
            val tcpAddr = toTcp(resolver)
            var c: VaydnsClient? = null
            var usedAddr = udpAddr
            if (tcpAddr != null) {
                try {
                    LogState.addLog("Mencoba TCP DNS: $tcpAddr")
                    c = Vaydns.newClient(tcpAddr, server, publicKey, LISTEN_ADDR)
                    usedAddr = tcpAddr
                } catch (e: Throwable) {
                    Log.w(TAG, "TCP gagal", e)
                    LogState.addLog("Library DNSTT tidak mendukung TCP. Coba jaringan lain (WiFi).")
                    c = null
                }
            }
            try {
                if (c == null) c = Vaydns.newClient(udpAddr, server, publicKey, LISTEN_ADDR)
                if (!isActive) {
                    c?.stop()
                    return@launch
                }
                client = c
                if (dnsType == "AUTO") {
                    try {
                        c?.setRecordType("NULL")
                        c?.start()
                    } catch (e: Throwable) {
                        Log.w(TAG, "NULL gagal, fallback TXT", e)
                        LogState.addLog("NULL gagal, fallback ke TXT")
                        try { c?.stop() } catch (_: Throwable) {}
                        if (!isActive) return@launch
                        c = Vaydns.newClient(usedAddr, server, publicKey, LISTEN_ADDR)
                        client = c
                        c?.setRecordType("TXT")
                        c?.start()
                    }
                } else {
                    c?.setRecordType(dnsType.uppercase())
                    c?.start()
                }
            } catch (e: Throwable) {
                Log.e(TAG, "DNSTT gagal", e)
                if (tcpAddr != null) LogState.addLog("Library DNSTT tidak mendukung TCP. Coba jaringan lain (WiFi).")
                LogState.addLog("Error: ${e.message ?: e.javaClass.simpleName}")
                if (e.cause != null) LogState.addLog("Cause: ${e.cause?.message}")
                startError = e
            }
        }
    }

    /** IP/host polos -> tcp://host:port. URL (DoH dll) dibiarkan -> null. */
    private fun toTcp(r: String): String? {
        val s = r.trim()
        if (s.isEmpty() || s.contains("://")) return null
        return "tcp://" + withPort(s)
    }

    /** IP/host polos -> tambah :53; yang sudah ada port atau URL (https://...) dibiarkan. */
    private fun withPort(r: String): String {
        val s = r.trim()
        if (s.contains("://")) return s
        if (s.startsWith("[")) return if (s.contains("]:")) s else "$s:53"
        return when (s.count { it == ':' }) {
            0 -> "$s:53"
            1 -> s
            else -> "[$s]:53"
        }
    }

    fun error(): Throwable? = startError

    fun isRunning(): Boolean = client?.isRunning ?: false

    fun stop() {
        job?.cancel()
        job = null
        val c = client
        client = null
        if (c != null) {
            try {
                c?.stop()
            } catch (e: Throwable) {
                Log.w(TAG, "stop gagal", e)
            }
        }
    }
}
