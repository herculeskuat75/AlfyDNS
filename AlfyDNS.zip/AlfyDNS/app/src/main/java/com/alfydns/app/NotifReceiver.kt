package com.alfydns.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Menangkap tombol PUTUS / SAMBUNG ULANG dari notifikasi (PendingIntent.getBroadcast). */
class NotifReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val svc = VpnSvc.instance
        when (intent.action) {
            VpnSvc.ACTION_STOP -> {
                LogState.addLog("Notifikasi: tombol PUTUS")
                if (svc != null) svc.stopVpn() else {
                    VpnState.mutable.value = VpnStatus.DISCONNECTED
                    context.stopService(Intent(context, VpnSvc::class.java))
                }
            }
            VpnSvc.ACTION_RECONNECT -> {
                LogState.addLog("Notifikasi: tombol SAMBUNG ULANG")
                if (svc != null) svc.reconnect()
                else VpnSvc.restartIntent(context)?.let { ContextCompat.startForegroundService(context, it) }
            }
        }
    }
}
