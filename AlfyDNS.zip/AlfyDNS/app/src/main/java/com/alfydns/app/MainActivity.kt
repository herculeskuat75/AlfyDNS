package com.alfydns.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private var pendingServer = ""
    private var pendingNs = ""
    private var pendingKey = ""
    private var pendingResolver = ""

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) startVpnService()
        }

    private var bgImage by mutableStateOf<ImageBitmap?>(null)

    private val prefs by lazy { getSharedPreferences("alfydns", MODE_PRIVATE) }

    private val pickBackground =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri != null) saveBackground(uri)
        }

    private fun saveBackground(uri: Uri) {
        try {
            val f = File(filesDir, "bg_${System.currentTimeMillis()}.img")
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                ?: return
            val old = prefs.getString("bg_uri", null)
            prefs.edit().putString("bg_uri", Uri.fromFile(f).toString()).apply()
            old?.let { Uri.parse(it).path?.let { p -> File(p).delete() } }
            loadBackground()
        } catch (_: Throwable) {}
    }

    private fun clearBackground() {
        prefs.getString("bg_uri", null)?.let { Uri.parse(it).path?.let { p -> File(p).delete() } }
        prefs.edit().remove("bg_uri").apply()
        bgImage = null
    }

    private fun loadBackground() {
        val path = prefs.getString("bg_uri", null)?.let { Uri.parse(it).path }
        if (path == null) { bgImage = null; return }
        try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, b)
            var sample = 1
            while (b.outWidth / sample > 1600 || b.outHeight / sample > 1600) sample *= 2
            val o = BitmapFactory.Options().apply { inSampleSize = sample }
            bgImage = BitmapFactory.decodeFile(path, o)?.asImageBitmap()
        } catch (_: Throwable) { bgImage = null }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            prepareVpn()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadBackground()
        setContent {
            val status by VpnState.status.collectAsState()
            MainScreen(
                status = status,
                onConnect = { server, resolver, ns, key ->
                    pendingServer = server
                    pendingResolver = resolver
                    pendingNs = ns
                    pendingKey = key
                    connect()
                },
                onDisconnect = ::disconnect,
                background = bgImage,
                onPickBackground = { pickBackground.launch("image/*") },
                onClearBackground = ::clearBackground
            )
        }
    }

    private fun connect() {
        val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotifPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            prepareVpn()
        }
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent == null) startVpnService() else vpnPermissionLauncher.launch(intent)
    }

    private fun startVpnService() {
        VpnState.mutable.value = VpnStatus.CONNECTING
        ContextCompat.startForegroundService(
            this,
            Intent(this, VpnSvc::class.java)
                .setAction(VpnSvc.ACTION_START)
                .putExtra(VpnSvc.EXTRA_SERVER, pendingServer)
                .putExtra(VpnSvc.EXTRA_NS, pendingNs)
                .putExtra(VpnSvc.EXTRA_KEY, pendingKey)
                .putExtra(VpnSvc.EXTRA_RESOLVER, pendingResolver)
        )
    }

    private fun disconnect() {
        startService(Intent(this, VpnSvc::class.java).setAction(VpnSvc.ACTION_STOP))
        VpnState.mutable.value = VpnStatus.DISCONNECTED
    }
}
