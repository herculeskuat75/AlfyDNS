package com.alfydns.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private var pendingServer = ""
    private var pendingNs = ""
    private var pendingKey = ""
    private var pendingResolver = ""

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) startVpnService()
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            prepareVpn()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val status by VpnState.status.collectAsState()
            MainScreen(
                status = status,
                onConnect = { server, resolver, ns, key ->
                    pendingServer = server
                    pendingResolver = resolver
                    pendingNs = ns
                    pendingKey = key
                    connect()
                },
                onDisconnect = ::disconnect
            )
        }
    }

    private fun connect() {
        val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotifPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            prepareVpn()
        }
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent == null) startVpnService() else vpnPermissionLauncher.launch(intent)
    }

    private fun startVpnService() {
        VpnState.mutable.value = VpnStatus.CONNECTING
        ContextCompat.startForegroundService(
            this,
            Intent(this, VpnSvc::class.java)
                .setAction(VpnSvc.ACTION_START)
                .putExtra(VpnSvc.EXTRA_SERVER, pendingServer)
                .putExtra(VpnSvc.EXTRA_NS, pendingNs)
                .putExtra(VpnSvc.EXTRA_KEY, pendingKey)
                .putExtra(VpnSvc.EXTRA_RESOLVER, pendingResolver)
        )
    }

    private fun disconnect() {
        startService(Intent(this, VpnSvc::class.java).setAction(VpnSvc.ACTION_STOP))
        VpnState.mutable.value = VpnStatus.DISCONNECTED
    }
}
