package com.alfydns.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private var status by mutableStateOf(VpnStatus.DISCONNECTED)

    private val vpnPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) startVpnService()
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            prepareVpn()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainScreen(
                status = status,
                onConnect = ::connect,
                onDisconnect = ::disconnect
            )
        }
    }

    private fun connect() {
        val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsNotifPermission) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            prepareVpn()
        }
    }

    private fun prepareVpn() {
        val intent = VpnService.prepare(this)
        if (intent == null) startVpnService() else vpnPermissionLauncher.launch(intent)
    }

    private fun startVpnService() {
        status = VpnStatus.CONNECTING
        ContextCompat.startForegroundService(
            this,
            Intent(this, VpnSvc::class.java).setAction(VpnSvc.ACTION_START)
        )
    }

    private fun disconnect() {
        startService(Intent(this, VpnSvc::class.java).setAction(VpnSvc.ACTION_STOP))
        status = VpnStatus.DISCONNECTED
    }
}
